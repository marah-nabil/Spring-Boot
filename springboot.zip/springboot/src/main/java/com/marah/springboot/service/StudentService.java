
package com.marah.springboot.service;

import com.marah.springboot.model.Student;
import com.marah.springboot.repository.StudentRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
    
    private final StudentRepository studentRepository;
    
    public StudentService(StudentRepository studentRepository){
        this.studentRepository =studentRepository;
    }
    
    public List<Student> getAllStudents(){
       return studentRepository.findAll();
    }
    
    public Optional<Student> getStudentById(Long id){
        return studentRepository.findById(id);
    }
    public Student saveStudent(Student student){
        return studentRepository.save(student);
    }
    public Student updateStudent(Long id, Student updatedStudent){
        return studentRepository.findById(id).map(student -> {
                student.setName(updatedStudent.getName());
                student.setMajor(updatedStudent.getMajor());
                student.setGrade(updatedStudent.getGrade());
                return studentRepository.save(student);
        }).orElseThrow(() -> new RuntimeException("Student not found"));
    }
    
    public void deleteStudent(Long id){
        studentRepository.deleteById(id);
    }
}
