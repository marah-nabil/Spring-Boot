
package com.marah.springboot.controller;

import com.marah.springboot.model.Course;
import com.marah.springboot.model.Student;
import com.marah.springboot.repository.CourseRepository;
import com.marah.springboot.repository.StudentRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.*;

@RestController
public class MainController {
    
    @Autowired
    StudentRepository studentRepository;
    
    @Autowired
    CourseRepository courseRepository;
    
    
    @RequestMapping("/")
    public String Index(){
        return String.format("%s", "Jpa Using spring boot");
    }

    //view student by id
    @RequestMapping("/showstudent/{id}")
    public String showStudent(@PathVariable Long id){
        Student student = studentRepository.findById(id).get();
        String str="";
        return String.format("%s", student);
    }
    
    //اضافة كورس جديد
    @RequestMapping("/addcourse")
    public String addCourse(@RequestParam Long id,
                            @RequestParam String name,
                            @RequestParam String location){
        Course course = new Course(id,name,location);
        courseRepository.save(course);
        return "Course added: "+course;
    }
     //عرض كل الكورسات
    @RequestMapping("/showallcourses")
    public String ShowCourses(){
        List<Course> courses = courseRepository.findAll();
        StringBuilder str= new StringBuilder();
        for(Course c: courses)
            str.append(c).append("<br>");
        return str.toString();
    }
      //اضافة طالب جديد مرتبط بكورس
    @RequestMapping("/addٍstudent")
    public String addStudent(@RequestParam String name,
                            @RequestParam String major,
                            @RequestParam Double grade,
                            @RequestParam Long courseId){
        Course course = courseRepository.findById(courseId).orElse(null);
        if(course == null){
            return "Course with id "+ courseId+" not found!";
        }
        Student student = new Student(name, major, grade, course);
        studentRepository.save(student);
        return "Student added: "+student;
    }
        //عرض كل الطلاب
    @RequestMapping("/showallstudent")
    public String ShowAllstudent(){
        List<Student> students = studentRepository.findAll();
        String str="";
        for(Student s: students)
            str += s  +" <br>";
        return String.format("%s", str);
    }
    
    //حذف طالب
    @RequestMapping("/deletestudent/{id}")
    public String deletestudent(@PathVariable Long id){
        if(!studentRepository.existsById(id)){
            return "Student not found!";
        }
        studentRepository.deleteById(id); 
        return "Student with ID= "+id+"deleted.";
    }
}
