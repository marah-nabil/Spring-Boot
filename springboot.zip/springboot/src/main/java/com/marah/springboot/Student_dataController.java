
package com.marah.springboot;

import com.marah.springboot.model.Course;
import com.marah.springboot.model.Student;
import com.marah.springboot.repository.CourseRepository;
import com.marah.springboot.repository.StudentRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Student_dataController {

    @Autowired
    private StudentRepository studentRepository;
    
    @Autowired
    private CourseRepository courseRepository;
    
    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField majorField;
    @FXML private TextField gradeField;
    
    @FXML private TextField idcField;
    @FXML private TextField namecField;
    @FXML private TextField locationField;
    
    @FXML private Button addBtn;
    @FXML private Button updateBtn;
    @FXML private Button deleteBtn;
    @FXML private Button resetBtn;
    @FXML private Button exitBtn;
    
    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, Long> idCol;
    @FXML private TableColumn<Student, String> nameCol,majorCol;
    @FXML private TableColumn<Student, Double> gradeCol;
    @FXML private TableColumn<Student, Long> courseIdCol;
    @FXML private TableColumn<Student, String> courseNameCol,courseLocationCol;

   
    @FXML
    private void initialize() {
        idCol.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getId()));
        nameCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));
        majorCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getMajor()));
        gradeCol.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getGrade()));
        
        courseIdCol.setCellValueFactory(c -> new SimpleObjectProperty<>(
        c.getValue().getCourse() != null ? c.getValue().getCourse().getId() : null));
        
        courseNameCol.setCellValueFactory(c -> new SimpleStringProperty(
        c.getValue().getCourse() != null ? c.getValue().getCourse().getName() : ""));        
        
        courseLocationCol.setCellValueFactory(c -> new SimpleStringProperty(
        c.getValue().getCourse() != null ? c.getValue().getCourse().getLocation() : ""));
        
        
        loadStudents();
    }
    private void loadStudents(){
        ObservableList<Student> students =FXCollections.observableArrayList(studentRepository.findAll());
        studentTable.setItems(students);
    }
   @FXML
    private void handleAdd() {
        try {
            Long courseId = Long.valueOf(idcField.getText());
            String courseName = namecField.getText();
            String Location = locationField.getText();
            
            Course course = courseRepository.findById(courseId)
                    .orElse(new Course(courseId,courseName,Location));
            course.setName(courseName);
            course.setLocation(Location);
            courseRepository.save(course);
            
            Student s= new Student(nameField.getText(),
                    majorField.getText(),Double.valueOf(gradeField.getText()),course);
            studentRepository.save(s);
            
            info("Student Added. ");
            loadStudents();
            clearStudentFields();
        }catch (Exception e){
            error(prettySqlError(e));
        }
    }

    @FXML
    private void handleUpdate() {
         try {
            Long id = Long.valueOf(idField.getText());
            Student s =studentRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Student not found"));
            
            s.setName(nameField.getText());
            s.setMajor(majorField.getText());
            s.setGrade(Double.valueOf(gradeField.getText()));
            
            Long courseId = Long.valueOf(idcField.getText());
            String courseName = namecField.getText();
            String Location = locationField.getText();
            
            Course course = courseRepository.findById(courseId)
                    .orElse(new Course(courseId,courseName,Location));
            course.setName(courseName);
            course.setLocation(Location);
            courseRepository.save(course);
            //ربط الطالب بالكورس
               s.setCourse(course);
               studentRepository.save(s);
               
            info("Student Updated. ");
            loadStudents();
            clearStudentFields();
        }catch (Exception e){
            error(prettySqlError(e));
        }
    }

    @FXML
    private void handleDelete() {
         try {
            Long id = Long.valueOf(idField.getText());
            studentRepository.deleteById(id);
            info("Student deleted. ");
            loadStudents();
            clearStudentFields();
        }catch (Exception e){
            error(prettySqlError(e));
        }
    }

    @FXML
    private void handleReset(ActionEvent event) { clearStudentFields(); }

    @FXML
    private void handleExit(ActionEvent event) { System.exit(0); }

    private void info(String m) {
       new Alert(Alert.AlertType.INFORMATION,m).showAndWait();
    }
    private void error(String m) {
       new Alert(Alert.AlertType.ERROR,m).showAndWait();
    }
    private void clearStudentFields() {
        idField.clear(); nameField.clear(); majorField.clear(); gradeField.clear();
        idcField.clear(); namecField.clear(); locationField.clear();
    }
    private boolean confirm(String m) {
        return new Alert(Alert.AlertType.CONFIRMATION,m, ButtonType.YES,ButtonType.NO)
                .showAndWait().orElse(ButtonType.NO) == ButtonType.YES;
    }
    private String prettySqlError(Exception e){
        String msg = e.getMessage();
        if(msg != null && msg.contains("Duplicate entry")) return "id is exists";
        if(msg != null && msg.contains("Unknown DB")) return "Name of DB is uncorrect";
        if(msg != null && msg.contains("Communication link failure entry")) return "MySQL not run";
        return msg;
    }
  

}

