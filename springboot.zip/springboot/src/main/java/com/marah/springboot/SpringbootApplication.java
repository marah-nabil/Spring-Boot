package com.marah.springboot;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringbootApplication extends Application{

    private ConfigurableApplicationContext springContext;
	public static void main(String[] args) {
		//SpringApplication.run(SpringbootApplication.class, args);
                launch(args);
	}
    @Override
    public void init(){
        springContext = new SpringApplicationBuilder(SpringbootApplication.class)
                .headless(false)
                .run();  
    }
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader =new FXMLLoader(getClass().getResource("/fxml/student_data.fxml"));
        loader.setControllerFactory(springContext::getBean);
        
        //Parent root = loader.load();        // FXML has <BorderPane ...>
        
        BorderPane root = new BorderPane();
        loader.setRoot(root);
        loader.load();
        Scene scene = new Scene(root);
        stage.setTitle("Student Management Page JPA with Spring Boot");
        stage.setScene(scene);
        stage.show();
       
    }
    
     @Override
    public void stop(){
        springContext.close();
    }

}
