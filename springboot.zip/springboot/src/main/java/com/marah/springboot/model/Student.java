
//Marah Nabil Salama
//220222441

package com.marah.springboot.model;

import jakarta.persistence.*;

@Entity
@Table(name ="students")
public class Student {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    
    private String major;
    
    private double grade;
    
    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;
    
    
    public Student() { }

    public Student(String name, String major, double grade,Course course) {
        this.name = name;
        this.major = major;
        this.grade = grade;
        this.course=course;
    }

    public String getMajor() {
        return major;
    }
    public void setMajor(String major) {
        this.major = major;
    }

    public double getGrade() {
        return grade;
    }
    public void setGrade(double grade) {
        this.grade = grade;
    }
  
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }  

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", major=" + major + ", grade=" + grade + ", course=" + 
                (course != null ? course.getName() : "null" ) + '}';
    }
 
    
    
}
