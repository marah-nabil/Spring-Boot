
//Marah Nabil Salama
//220222441

package com.marah.springboot.model;

import java.util.*;
import jakarta.persistence.*;


@Entity
@Table(name = "course")
public class Course {
    
     
    @Id
    private Long id;
    
    private String name;
    
    private String location;

     @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
     private List<Student> students = new ArrayList<>();
    
     public Course() {}

    public Course(Long id,String name, String location) {
        this.id=id;
        this.name = name;
        this.location = location;
    }

    public Long getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<Student> getStudent() {
        return students;
    }

    public void setStudent(List<Student> students) {
        this.students=students;
    }

    @Override
    public String toString() {
        return "Course{" + "id=" + id + ", name=" + name + 
                ", location=" + location + '}';
    }
 
    

}
